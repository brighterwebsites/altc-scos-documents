# **Content Pillar Gap Analysis Framework**

*Medium-Depth, Agency-Ready Version*

**Purpose:** To evaluate whether the business is producing a balanced mix of content that supports trust, visibility, engagement, and conversions. The right pillar distribution ensures the brand is not “all promo”, “all fluff”, or “all awareness”.

This framework guides GPT to identify:

* Pillars present  
* Pillars missing  
* Over-represented content types  
* Strategic recommendations  
* Industry-appropriate balance

Use feed screenshots to assess — never assume beyond what is visible.

---

# **1\. Core Content Pillars (6-Pillar Model)**

These are the universal pillars for Australian service-based businesses.

## **1\. Authority & Education**

Shows expertise. Builds trust. Examples:

* Tips  
* How-to content  
* Explainers  
* FAQs  
* Industry insights  
* “5 things to know before…” posts

Signals: ✓ Expertise ✓ Value-led content ✓ Local relevance if geographic keywords are used

---

## **2\. Proof & Results**

The most powerful pillar for service brands.

Examples:

* Before/after  
* Case studies  
* Testimonials  
* Review screenshots  
* Project breakdowns  
* Client photos / UGC

Signals: ✓ Credibility ✓ Demonstrated outcomes ✓ Reduces purchase hesitation

---

## **3\. Local Content**

Essential for local service providers.

Examples:

* Behind-the-scenes in the local area  
* Community events  
* Local shoutouts  
* “Serving Ballarat, Bendigo, Geelong…”  
* Local landmarks  
* Local client stories

Signals: ✓ Local relevance ✓ Community connection ✓ Improves IG/Facebook reach for local keywords

---

## **4\. Brand Personality**

Human connection.

Examples:

* Team photos  
* Founder story  
* Office culture  
* Work-day snippets  
* Pets, staff, BTS moments  
* Personal notes (lightly, strategically)

Signals: ✓ Trust ✓ Approachability ✓ Humanises the brand

---

## **5\. Promotional / Offers**

The sales-driving pillar.

Examples:

* Service descriptions  
* Offers  
* Pricing or quotes  
* CTAs  
* “DM to book”  
* Seasonal promotions  
* Package highlights

Signals: ✓ Conversion ✓ Clarity ✓ Direct path to enquiry

---

## **6\. Engagement-Optimised Content**

Designed to spark interaction.

Examples:

* Polls  
* Questions  
* Carousels with hooks  
* “Comment below…”  
* Quick reels  
* Trending formats (tastefully used)

Signals: ✓ Growth ✓ Algorithm-friendly ✓ Community building

---

# **2\. Recommended Pillar Mix (Agency Standard)**

This is the ideal pillar distribution for most service-based businesses:

* **30% Authority & Education**  
* **25% Proof & Results**  
* **20% Engagement-focused content**  
* **15% Brand Personality**  
* **10% Promotional**  
* **Local content:** interwoven throughout (not a fixed %)

This mix builds trust, authority, and conversion without feeling salesy.

GPT should NOT calculate percentages literally — instead, visually estimate balance from screenshots.

---

# **3\. How to Analyse From Screenshots**

Use this method:

1. **Scan the IG/Facebook feed** (last 9–12 posts visible)  
2. Identify which pillar each post belongs to  
3. Count rough representation (e.g., “3 promo, 1 proof, 0 educational…”)  
4. Compare to the recommended pillar mix  
5. Identify gaps or over-represented areas  
6. Provide corrections

**If a post is ambiguous**, prioritise the *strongest visible* pillar. **If a pillar cannot be identified**, write:

“Cannot determine from screenshots provided.”

Never guess at unseen posts.

---

# **4\. Gap Interpretation Framework**

This helps GPT explain the business implications.

---

## **A. Missing Authority/Education**

Implication:

* Not building trust  
* Limited organic reach  
* Feels like “just another provider”

Recommended Fix:

* Add weekly educational posts  
* Use FAQ carousels  
* Add 2–3 “value posts” across the grid

---

## **B. Missing Proof/Results**

Implication:

* Low credibility  
* Feels untested or inexperienced  
* Fewer enquiries convert

Recommended Fix:

* Create a “proof library”  
* Add 4–6 before/after or reviews per month  
* Turn reviews into carousels

---

## **C. Missing Local Content**

Implication:

* Weak local search visibility  
* Feels disconnected from service area  
* Competitors appear more relevant

Recommended Fix:

* Add geo-tagged reels  
* Showcase local client results  
* Add suburb/location callouts

---

## **D. Missing Brand Personality**

Implication:

* Brand feels cold or generic  
* No human connection  
* Engagement often drops

Recommended Fix:

* Add team photos  
* Behind-the-scenes stories  
* Founder-led content  
* Light personal notes (professional but warm)

---

## **E. Over-Promotional Feed**

Implication:

* Feels salesy; trust drops  
* Low engagement  
* Turns audience off

Recommended Fix:

* Reduce promo posts to \<10–15%  
* Introduce authority, proof, and personality  
* Add soft-CTA content

---

## **F. Missing Engagement Content**

Implication:

* Algorithm reach drops  
* Little to no community interaction  
* Feels flat or one-directional

Recommended Fix:

* Add polls, questions, carousels  
* Add short reels with hooks  
* Use engaging captions

---

# **5\. Example Audit Outputs**

### **Strong Pillar Presence Example**

“Your content shows strong balance across education, proof, and personality. This gives your brand trust and approachability, and positions you well against competitors.”

---

### **Weak Pillar Balance Example**

“Your feed is heavily promotional (6 of the last 9 posts). There is almost no evidence or educational content. This reduces trust and makes it harder for potential clients to feel confident reaching out.”

---

### **Missing Local Content Example**

“Your posts don’t reference your service area. Adding location-based content would improve discoverability for local customers and differentiate you in a competitive market.”

---

# **6\. Summary Output Template**

Use this structure inside your audit:

**Content Pillar Analysis**

* Authority/Education: Present / Missing  
* Proof & Results: Present / Missing  
* Local Content: Present / Missing  
* Brand Personality: Present / Missing  
* Promotional: Over/Under/Just Right  
* Engagement Content: Present / Missing

**Key Gaps:** 1\. 2\. 3\.

## **Recommended Improvements:**
