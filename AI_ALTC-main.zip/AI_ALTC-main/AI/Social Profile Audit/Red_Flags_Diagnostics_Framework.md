# **Red Flags & Diagnostics Framework**

*Medium-Depth, Agency-Ready Version* *For Social Media \+ Brand Alignment Audits*

This document gives the GPT a clear list of **legitimate, standards-based red flags** it can safely call out **without over-reaching**, **without guessing**, and **without shaming the user**.

Red Flags are **global** — they apply across *all* sections of a social/brand audit.

---

# **1\. Purpose of Red Flags**

Red Flags exist to help the GPT:

* Identify issues that hurt trust  
* Prioritise what matters most  
* Anchor Phase 1 and Phase 2 recommendations  
* Avoid inventing problems  
* Maintain consistency across audits  
* Avoid false alarms (e.g., judging a small account unfairly)

Red Flags **must be objective** and **visible in screenshots**.

---

# **2\. Red Flag Principles**

### **✔ ONLY call red flags if:**

* It is clearly visible  
* It is industry-appropriate  
* It affects trust, conversion, clarity or brand perception  
* It is actually hurting the user (not just a preference)

### **✘ DO NOT call red flags for:**

* Low follower count  
* Small reach  
* New accounts  
* Lack of reels (varies by industry)  
* Not using trends  
* Posting schedule personal preference  
* Analytics that cannot be seen

### **✔ Always frame red flags as opportunities, not failures.**

---

# **3\. Red Flags Categories**

The GPT uses these **seven categories** across all audits.

---

# **A. Visual Identity Red Flags**

Visible issues that hurt trust, credibility, or brand consistency.

* Pixelated logo or low-quality profile image  
* Mismatched colours between website and social  
* Inconsistent fonts  
* Disjointed feed (no cohesive style)  
* Overly busy templates  
* Unstyled photography  
* Poor lighting or obvious amateur images  
* Irregular visual tone (corporate → casual → chaotic → premium)  
* Excessive use of unrelated stock images  
* Off-brand memes or novelty graphics

**Why it matters:** Visual inconsistency breaks trust and makes the brand appear unreliable or unprofessional.

---

# **B. Messaging Red Flags**

Issues in copy, captions, bios, or headlines.

* Unclear value proposition  
* No location mentioned (for a local service)  
* No CTA  
* Services not identifiable  
* Tone of voice inconsistent  
* Mismatch between website message and social message  
* Industry jargon with no explanation  
* Captions too short or too vague  
* Everything sounds “samey”  
* No benefits or outcomes mentioned

**Why it matters:** Confusion reduces enquiries more than low reach does.

---

# **C. Content Red Flags**

Issues in post types, variety, or structure.

* Only promotional content (no value, no trust)  
* Only memes or low-effort content  
* No before/after or proof (in proof-heavy industries)  
* No education (in authority-heavy industries)  
* No brand personality at all  
* No local content (for local-first businesses)  
* No clear content pillars  
* Repeated posts with same template  
* Posts not readable or too text-heavy  
* Irrelevant content not aligned to business goals

**Why it matters:** Content must build trust, not just fill the feed.

---

# **D. Engagement & Community Red Flags**

Visible signals of weak or absent community interaction.

* Zero comments on all posts  
* Posts with extremely low traction *relative to* follower count  
* No responses to comments  
* No CTA or engagement prompts  
* Comments from bots  
* Posts receiving identical, repetitive emojis  
* Audience confusion (“Do you still operate?”)  
* Empty reviews sections on Facebook

### **⚠️ Important:**

**Low engagement is NOT automatically a red flag.** For local service industries, *low engagement is normal*. The red flag appears ONLY when:

* Follower count does not match engagement, or  
* There is no conversation at all

This distinction prevents unfair judgments.

---

# **E. Trust & Proof Red Flags**

Signals that harm credibility.

* No testimonials  
* No reviews shown  
* No before/after when expected (beauty, trades)  
* Old reviews (last review \> 6 months ago)  
* No case studies or results  
* No human presence (staff, clients, real work)  
* No social proof of expertise  
* Overly staged or unrealistic imagery  
* No UGC or “real world” content

**Why it matters:** Trust is a conversion driver for **every** service business.

---

# **F. Brand Alignment Red Flags**

Website ↔ Social misalignment issues.

* Website looks premium; social looks cheap (or vice versa)  
* Different colours, logos, or photography  
* Messaging conflict (“premium” on website, “cheap” on social)  
* Different service lists  
* Offers/pricing inconsistent across platforms  
* Tone mismatch (corporate website, casual IG)

**Why it matters:** Brand inconsistency pulls conversions down across all channels.

---

# **G. Competitive Red Flags**

Visible disadvantages compared to competitors.

* Competitor posts more proof  
* Competitor has stronger content variety  
* Competitor visual identity more polished  
* Competitor clearer service description  
* Competitor uses stronger CTAs  
* Competitor has more consistent posting pattern  
* Competitor has more local presence  
* Competitor showcases more expertise

⚠ These must *always* be framed as: **“Opportunities to differentiate”**, not shame-based comparisons.

---

# **4\. Industry Modifier Red Flags**

Some industries require more scrutiny in certain areas.

### **High-Visual Industries**

(Beauty, weddings, creatives) Red flags appear faster for:

* Poor aesthetics  
* Low-quality photos  
* Irregular visual identity

### **Technical/B2B Industries**

(Web design, SEO, accounting, legal) Red flags appear faster for:

* Lack of education  
* No authority content  
* Poor clarity

### **Trades**

(Plumbing, roofing, landscaping) Red flags appear faster for:

* Lack of proof  
* No before/after  
* No process content  
* No local relevance

### **Personal Services**

(Coaches, therapists, NDIS) Red flags appear faster for:

* No personality  
* No human presence  
* No empathy-led content

---

# **5\. Red Flag Output Template**

GPT should output something like:

**RED FLAGS IDENTIFIED** *(Based only on visible screenshots)*

## **Visual:**

## **Messaging:**

## **Content:**

## **Engagement:**

## **Trust:**

## **Brand Alignment:**

## **Competitive:**

This keeps things structured and client-friendly.
