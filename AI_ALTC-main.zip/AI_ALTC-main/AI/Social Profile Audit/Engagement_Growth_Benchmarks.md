# **Engagement & Growth Benchmarks**

*Medium-Depth, Agency-Ready Version* *For Australian Service-Based Businesses*

**Purpose:** To provide realistic, platform-specific benchmarks so GPT can evaluate whether a brand’s engagement, activity, and growth appear strong, average, or concerning **based on visible screenshots only**.

These benchmarks help ensure scoring is consistent and grounded.

---

# **1\. Benchmark Principles**

1. GPT should only judge engagement based on what’s visible

   * Likes  
   * Comments  
   * Caption quality  
   * Visual cues  
   * Recency of posts  
   * Interaction patterns  
2. GPT must **not attempt to calculate exact engagement rates**. Screenshots rarely show full metrics.

3. Language should reflect relativity, not precision:

* “Appears low for this industry…”  
* “Strong engagement relative to follower count…”  
* “Interaction patterns look above average…”  
4. If follower count or post insights aren’t shown:

**“Cannot determine full engagement rate from screenshot.”**

---

# **2\. Instagram Benchmarks**

Australia-wide averages for service brands (2024–2025):

### **Engagement**

* **Normal:** 1–3%  
* **Low:** \<1%  
* **Strong:** 3–6%  
* **Exceptional:** 6%+ (rare for service industries)

### **Posting Frequency**

* Ideal: **2–3 posts per week**  
* Minimum: **8–12 posts per month**  
* Stories: **3–5 days per week**  
* Reels: **1–2 per week** for healthy reach

### **Red Flags**

* No posts in 60+ days  
* Engagement \<1% *and* follower count unusually high  
* Reels only receive a handful of likes  
* Zero comments on last 9–12 posts  
* No responses to comments

### **Signs of Strong IG Health**

* Regular posting (weekly)  
* Consistent comments (even a few per post)  
* Content pillars clearly present  
* Mix of Reels, carousels, single images  
* At least some local content (if service-based)

---

# **3\. Facebook Benchmarks**

### **Engagement**

Facebook engagement is naturally lower. Realistic benchmarks:

* **Normal:** 0.5–1%  
* **Strong:** 1–2%  
* **Exceptional:** 2%+

Screenshots often show only likes \+ comments. Use qualitative indicators.

### **Posting Frequency**

* Ideal: **2–3 posts per week**  
* Story use varies (optional for service industries)

### **Red Flags**

* Page “dead” (no posts for months)  
* All posts get 0–1 likes  
* No comments on any recent posts  
* Same content duplicated from IG without adaptation  
* No replies to comments

### **Signs of Strong FB Health**

* Consistent (even small) engagement  
* Regular posting  
* Community interaction  
* UGC or review posts  
* Occasional long-form posts

---

# **4\. Growth Benchmarks**

Service businesses grow slowly unless supported by paid ads.

### **Instagram Growth**

* **Healthy:** 1–5% per month  
* **Strong:** 5–10% per month  
* **Exceptional:** 10%+ (usually with reels strategy)  
* **Flat growth:** common but fixable

### **Facebook Growth**

* Often minimal without:

  * boosted posts  
  * local content  
  * active community

Low post reach does not always reflect brand weakness.

---

# **5\. How GPT Should Interpret Engagement from Screenshots**

GPT should look for **patterns**, not exact numbers.

### **Identify:**

* Are posts receiving consistent likes?

* Are there real comments vs spam bot comments?

* Does engagement correlate with content type?

* Are recent posts more or less active than older ones?

* Are there signs of purchased followers?

  * High followers / almost no engagement

### **If the screenshot shows:**

* 5000 followers, but 3–8 likes → **major red flag**  
* 400 followers, but 20–40 likes → **strong engagement**  
* 0 comments across entire grid → **weak community health**

**Use wording such as:**

* “Appears low relative to typical service business benchmarks.”  
* “Appears strong given the visible follower count.”

---

# **6\. Red Flags & High-Value Signals**

## **Red Flags**

* Sudden engagement drops  
* No comments across the grid  
* Outdated posts (30+ days between posts)  
* Spammy comments  
* No video content  
* Identical posts across IG and FB with no optimisation  
* No replies to comments

## **Positive Signals**

* Consistent comments (even light)  
* Short reels receiving higher traction  
* UGC reposts  
* Localised content  
* Story highlights that reflect services  
* Reviews incorporated into posts  
* Mix of value \+ proof content

---

# **7\. Example Audit Interpretation Outputs**

### **Weak Engagement Example**

“Most recent posts show very limited engagement (likes in the low single digits and no comments). This suggests the brand isn’t generating meaningful visibility or conversation, which is typical when posting frequency is low or the content pillars are imbalanced.”

### **Healthy Engagement Example**

“Likes and comments are consistent across recent posts, indicating a healthy relationship with the existing audience. This level of engagement is strong for a service business in this industry.”

### **Suspicious Growth Example**

“Follower count appears inflated compared to visible engagement. This gap is a red flag for purchased followers or legacy audience mismatch.”

---

# **8\. Summary Output Template**

Use this for audit output:

**Engagement & Growth Summary**

* IG Engagement: Strong / Average / Weak  
* FB Engagement: Strong / Average / Weak  
* Posting Frequency: Meets / Lags / Exceeds benchmarks  
* Growth Indicators: Healthy / Flat / Cannot determine

## **Red Flags:**

## **Positive Signals:**
