# **Visual Identity Scoring Matrix**

*Medium-Depth, Agency-Ready Version*

**Purpose:** To evaluate the professionalism, cohesion, and clarity of a brand’s visual identity across social platforms (Instagram \+ Facebook) and website screenshots.

This score influences:

* Trust  
* Perceived quality  
* Conversion  
* Brand recognition  
* Narrative clarity

This document guides the GPT to score consistently, interpret results accurately, and recommend practical improvements.

---

# **1\. Visual Identity Score (0–10)**

| Score | Meaning | Interpretation |
| :---- | :---- | :---- |
| **0–3** | Poor | Disjointed, low-quality visuals, inconsistent style. Hurts trust. |
| **4–6** | Mixed | Some good elements but lacks cohesion. DIY feel. |
| **7–8** | Strong | Professional, intentional, fairly cohesive. Small refinements needed. |
| **9–10** | Excellent | Highly professional, consistent, branded, trust-building. |

When in doubt, default to the **middle band (4–6)** unless clear evidence indicates otherwise.

If imagery or brand elements are unclear due to screenshot limitations:

**“Cannot determine from screenshots provided.”**

---

# **2\. Elements to Score (Breakdown)**

Each category contributes to the overall 0–10 visual identity score.

---

## **A. Colour Consistency**

Evaluate whether core colours appear consistently across:

* Website  
* IG profile \+ grid  
* Facebook  
* Highlights, templates, graphics

### **Strong Indicators (Score 7–10)**

* Same primary colour palette appears everywhere  
* Tints/shades consistent  
* No random off-brand colours  
* Template colours match website palette

### **Weak Indicators (Score 0–3)**

* Website navy blue / socials pastel pink  
* No obvious palette  
* Feels chaotic or mismatched  
* Templates inconsistent

---

## **B. Font Consistency**

You are not checking *exact fonts* — only stylistic alignment.

### **Strong Indicators**

* Sans-serif everywhere (simple, modern)  
* Or consistent use of serif/sans pairings  
* Headers/captions visually similar to the website  
* No chaotic mix of styles

### **Weak Indicators**

* Website uses clean modern fonts; socials use novelty fonts  
* Inconsistent type treatments  
* Low legibility  
* Multiple clashing font styles

---

## **C. Image Quality**

Evaluate:

* Clarity  
* Professionalism  
* Exposure  
* Composition  
* Cropping  
* Intentionality

### **Strong Indicators**

* Clean, crisp images  
* Consistent shooting/editing style  
* High-resolution work photos  
* On-brand tone

### **Weak Indicators**

* Blurry images  
* Random selfies mixed with service work  
* Inconsistent lighting  
* Pixelated or low-res images

---

## **D. Cohesiveness**

Does the brand *feel* unified across platforms?

### **Strong Indicators**

* Posts feel part of the same identity  
* Consistent spacing, framing, composition  
* Repeated brand motifs (icons, shapes, overlays)

### **Weak Indicators**

* Every post looks like it was made in a different app  
* No recurring style  
* Random content with no visual through-line

---

## **E. Intentionality**

Is the design deliberate or accidental?

### **Strong Indicators**

* Thoughtful layout  
* Balanced aesthetic  
* Planned templates  
* Consistent grid themes

### **Weak Indicators**

* DIY or last-minute feel  
* No clear creative direction  
* Visual noise or clutter  
* Overuse of default Canva elements

---

# **3\. How to Assess from Screenshots**

This section gives the GPT practical instructions for interpreting visuals without hallucinating.

* **Compare website colours vs. top 9–12 IG posts vs. Facebook cover/profile areas**

* Identify whether visuals share similar:

  * tones (warm/cool)  
  * saturation  
  * brightness  
  * composition style  
* **Look for repeated design elements** (lines, shapes, borders, overlays)

* **Check for style contradictions:**

  * website premium / socials cheap  
  * website minimal / socials busy  
  * website earthy / socials neon  
* If screenshots are partial or unclear, write:

  “Cannot determine from screenshots provided.”

---

# **4\. Interpretation Framework (How to Explain Score)**

Use this guidance when writing the audit output.

---

## **Score 9–10 — Excellent**

* Visual identity is highly cohesive  
* Feels premium and intentional  
* Professional-level photography  
* Consistent colour \+ typography \+ layout  
* Strong trust impact

**Example Output** “The visual identity is exceptionally consistent across website and socials — clean typography, unified colour palette, and high-quality imagery that reinforces the brand promise.”

---

## **Score 7–8 — Strong**

* Mostly professional  
* Clear brand direction  
* Minor inconsistencies but nothing harmful  
* Very good trust-building foundation

**Example Output** “The brand feels cohesive and well-designed, with just a few refinements needed to polish the overall aesthetic.”

---

## **Score 4–6 — Mixed**

* Good foundation but too many inconsistencies  
* Some posts strong; some visually weak  
* Feels partially DIY  
* Trust impact is neutral or slightly reduced

**Example Output** “There are pockets of strong brand identity, but inconsistency across colours and image quality reduces the overall professionalism.”

---

## **Score 0–3 — Poor**

* Strong disconnect between platforms  
* Visual identity unclear or mismatched  
* Strong DIY or unprofessional appearance  
* Trust is negatively impacted

**Example Output** “The website and socials feel visually disconnected, with inconsistent colours, mixed photography quality, and no clear creative direction.”

---

# **5\. Recommended Fixes (Scenario-Based)**

Use these to generate actionable recommendations in audits.

---

## **Scenario 1: Colours inconsistent**

* Select a primary palette (3–5 colours)  
* Update template posts to match website colours  
* Refresh highlights/icons  
* Align Facebook cover with IG \+ website palette

---

## **Scenario 2: Fonts all over the place**

* Choose a consistent heading \+ body style  
* Standardise all graphics templates  
* Avoid novelty fonts  
* Ensure typography matches website tone

---

## **Scenario 3: Mixed-quality images**

* Create a bank of 20–30 branded images  
* Reshoot key service photos  
* Retire pixelated or blurry images  
* Introduce consistent editing presets

---

## **Scenario 4: Feels DIY / inconsistent**

* Create branded template pack (10–15 templates)  
* Define a consistent grid style  
* Use unified spacing and alignment  
* Establish a consistent photo-editing style

---

## **Scenario 5: Website premium, socials not**

* Match social photography to website images  
* Align visual tone (warm, dark, modern, airy, etc.)  
* Use high-quality graphics aligned with web branding  
* Update profile/cover imagery

---

## **Scenario 6: Socials strong, website outdated**

* Refresh the website with current brand visuals  
* Replace outdated photos  
* Align CTA styles  
* Update colour system across website

---

# **6\. Summary Output Template**

When summarising visual identity findings, use:

**Visual Identity Score: X/10**

* **Colours:**  
* **Fonts:**  
* **Image Quality:**  
* **Cohesiveness:**  
* **Intentionality:**

**Top Opportunities:** 1\. 2\. 3\.
