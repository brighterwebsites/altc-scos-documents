# **Funnel Stage Coverage Framework**

*Medium-Depth, Agency-Ready Version*

**Purpose:** To evaluate whether the brand’s content covers the **full buyer journey** — from awareness (TOF) to trust-building (MOF) to conversion (BOF). Service-based businesses especially need balanced funnel coverage to move strangers → warm leads → paying clients.

This framework helps GPT determine:

* Which funnel stages are strong  
* Which are weak or missing  
* What the missing stages mean for business growth  
* How to fix the gaps

Use only what is visible in the screenshots.

---

# **1\. Funnel Stages Overview**

## **Top of Funnel (TOF) — Awareness / Reach / Discovery**

**Purpose:** Make new people aware your brand exists.

**Examples:**

* Educational reels  
* Broad tips  
* Industry insights  
* Local-focused content  
* Trend-based content (tasteful, brand-aligned)  
* “What we do” overviews  
* Light brand personality content

**Indicators of TOF strength:**

* Reels  
* Carousels with hooks  
* Educational graphics  
* Local area references  
* High reach potential posts

---

## **Middle of Funnel (MOF) — Trust / Relationship Building**

**Purpose:** Help potential clients understand who you are and why you’re credible.

**Examples:**

* Behind-the-scenes  
* Team intros  
* FAQ content  
* Case study breakdowns  
* Service explainers (non-promotional)  
* Journey/process explanations  
* Client stories

**Indicators of MOF strength:**

* Story-driven content  
* Founder/owner videos  
* Workflow/process content  
* Human-focused images  
* Replying to comments/DMs

---

## **Bottom of Funnel (BOF) — Conversion / Decision-Making**

**Purpose:** Make it easy for people to enquire, book, or purchase.

**Examples:**

* Before/after  
* Testimonials  
* Review screenshots  
* Offers  
* CTAs (“Book now”, “Message us for a quote”)  
* Pricing clarity  
* Service-specific posts  
* “What’s included” breakdowns

**Indicators of BOF strength:**

* High-proof content  
* Clear CTAs  
* Service detail posts  
* Booking links in bios/highlights  
* Promotional posts

---

# **2\. How to Analyse Funnel Coverage from Screenshots**

GPT should follow this process:

1. **Scan the last 9–12 visible posts** (or the most relevant screenshots).

2. **Assign each post** to TOF, MOF, or BOF.

3. **Count rough distribution** (e.g., 5 TOF, 2 MOF, 1 BOF).

4. Compare to the **recommended funnel balance**.

5. Identify:

   * Missing stages  
   * Over-represented stages  
   * Balance issues  
   * Strategic implications  
6. Recommend a **corrective strategy** based on the gaps.

If unclear, write:

**“Cannot determine funnel stage for this post from the screenshot.”**

Never guess at unseen content.

---

# **3\. Recommended Funnel Mix (Agency Standard)**

For service providers:

* **TOF (Awareness): 40%**  
* **MOF (Trust-Building): 35%**  
* **BOF (Conversion): 25%**

This ensures:

* Healthy reach  
* Steady trust-building  
* Strong conversion signals

---

# **4\. Funnel Gap Interpretation Framework**

This section helps GPT describe the business implications and corrections.

---

## **A. Missing TOF (Awareness)**

**Implications:**

* Low reach  
* Slow growth  
* Harder for new customers to discover the brand

**Recommended Fixes:**

* Add educational reels  
* Add community/local content  
* Use carousels with strong hooks  
* Share broad value-based posts

---

## **B. Missing MOF (Trust-Building)**

**Implications:**

* Audience doesn’t connect personally  
* Feels transactional or faceless  
* Conversions drop despite good reach

**Recommended Fixes:**

* Share more behind-the-scenes  
* Introduce team/founder stories  
* Add process explainers  
* Use carousel FAQs  
* Increase personality in captions

---

## **C. Missing BOF (Conversion)**

**Implications:**

* Audience uncertain how to take action  
* Enquiries lower than they should be  
* Followers don’t convert

**Recommended Fixes:**

* Add more before/after  
* Add testimonials or review screenshots  
* Clarify CTAs  
* Add “What’s included” service breakdowns  
* Promote offers strategically

---

## **D. Overemphasis on TOF (all value/education)**

**Implications:**

* High reach, low conversions  
* Feels like “free content machine” with no clear service pathway

**Fix:**

* Add trust-driven and conversion-driven posts  
* Clarify CTAs

---

## **E. Overemphasis on BOF (too promotional)**

**Implications:**

* Feels salesy  
* Engagement drops  
* Limited organic reach

**Fix:**

* Reduce promo posts to \<25%  
* Add more educational and trust-building content

---

## **F. Overemphasis on MOF (all BTS)**

**Implications:**

* Relatable, but not scalable  
* Not enough reach or conversion clarity  
* Feels like personal blog

**Fix:**

* Add strategic educational content  
* Add clearer service explanations  
* Add conversion assets

---

# **5\. Example Funnel Assessment Outputs**

### **Example 1: Missing BOF**

“Your content is strong in awareness and personality, but lacks conversion assets like testimonials and service-specific posts. This makes it harder for followers to understand what you offer or why they should enquire.”

---

### **Example 2: Missing MOF**

“Your grid shows great educational content but very little behind-the-scenes or process storytelling. Adding trust-building posts will help people feel more confident choosing you.”

---

### **Example 3: Strong Funnel Balance**

“You have a healthy mix of awareness (TOF), trust-building (MOF), and conversion (BOF) content. This balance positions your brand strongly across the full buyer journey.”

---

# **6\. Summary Output Template**

Use this template in the final audit:

---

### **Funnel Stage Coverage**

* **TOF (Awareness):** Present/Weak/Missing  
* **MOF (Trust-Building):** Present/Weak/Missing  
* **BOF (Conversion):** Present/Weak/Missing

**Key Funnel Gaps:** 1\. 2\. 3\.

## **Recommended Fixes:**
