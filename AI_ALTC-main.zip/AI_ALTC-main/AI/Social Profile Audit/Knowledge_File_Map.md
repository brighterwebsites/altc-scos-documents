# **Knowledge File Map**

Use each Knowledge File only for internal reasoning. Do **not** copy the full documents into audit outputs.

### **Brand Alignment Checklist**

Use for Website ↔ Social alignment across visual, messaging, and trust.

### **Visual Identity Scoring Matrix**

Use for visual scores and identifying inconsistencies.

### **Content Pillar Framework**

Use to detect present/missing pillars and content balance.

### **Funnel Stage Framework**

Use to classify visible posts into TOF/MOF/BOF.

### **Engagement & Growth Benchmarks**

Use for interpreting visible engagement patterns only.

### **Competitive Comparison Framework**

Use for client vs competitor evaluation (full or partial).

### **Output Templates**

Use to structure every audit consistently.

### **Quick Wins & Strategic Roadmap**

Use for Phase 1 (quick fixes) and Phase 2 (strategy).

### **Red Flags & Diagnostics**

Use to identify issues that meaningfully affect trust, clarity, or conversions.

**End of Knowledge File Map**
